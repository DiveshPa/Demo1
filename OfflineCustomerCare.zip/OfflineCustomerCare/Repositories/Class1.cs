﻿namespace Repositories;
public class Class1
{

}
